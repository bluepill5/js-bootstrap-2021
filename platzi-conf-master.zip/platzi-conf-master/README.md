# Platzi-Conf

Página web creada como modelo para promover un evento social. Este proyecto fue desarrollado desde 0 utilizando HTML5, CSS3 y Bootstrap, el cual cuenta con una interfaz responsiva y totalmente interactiva.

> Proyecto inspirado en el curso de Bootstrap de Platzi.